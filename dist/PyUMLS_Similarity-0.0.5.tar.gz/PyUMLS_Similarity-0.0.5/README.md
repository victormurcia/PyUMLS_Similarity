This package computes a variety of similarity metrics between concepts present in the UMLS database. 

It is a Python wrapper based off a Perl module developed by Bridget McInnes and Ted Pedersen. 